<?php
namespace chestrap;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\utils\Config;
use pocketmine\math\Vector3;

class ChestTap extends PluginBase implements Listener { 

    public function onEnable() { 
        $this->getServer()->getPluginManager()->registerEvents($this, $this); 
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML); 
    } 

    public function onInteract(PlayerInteractEvent $e) { 
        $player = $e->getPlayer(); 
        $block = $e->getBlock(); 
        $item = $e->getItem(); 
        $x = $block->getX(); 
        $y = $block->getY(); 
        $z = $block->getZ(); 
        $level = $player->getLevel()->getFolderName(); 
       
        if (in_array($block->getId(), ["54", "146"]) && $player->isSneaking()) { 
            if (in_array($item->getId(), $this->cfg->get("not.use.item"))) return; 
            if ($player->isCreative() && !$this->cfg->get("use.creative")) return; 
            
            $chest = $this->getServer()->getLevelByName($level)->getTile(new Vector3($x, $y, $z)); 
            
            if (!$chest->getInventory()->canAddItem($item)) { 
                $player->sendMessage($this->cfg->get("msg.full")); 
            } else { 
                if (!isset($this->addChest[$player->getName()]) || ($this->addChest[$player->getName()] + 1) < time()) { 
                    $player->sendMessage(str_replace("%item%", $item->getName() . "§7(x" . $item->getCount() . ")", $this->cfg->get("msg"))); 
                    $chest->getInventory()->addItem($item); 
                    $player->getInventory()->removeItem($item); 
                    $this->addChest[$player->getName()] = time(); 
                } else { 
                    $player->sendMessage($this->cfg->get("msg.again")); 
                }
            } 
            $e->setCancelled(true); 
        } 
    } 
}